<?php
$a="meet";
echo password_hash($a, PASSWORD_DEFAULT)
?>